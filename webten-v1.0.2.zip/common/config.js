// Auto-generated config file - DO NOT EDIT MANUALLY
// This file is generated from environment variables during build

// Prevent redeclaration if already loaded
if (typeof self.PROXY_URL === 'undefined') {
    // Proxy server configuration (API keys are kept secure on the server)
    self.PROXY_URL = 'https://my-webten-proxy-d34725bef4b5.herokuapp.com';
}

if (typeof self.OPENAI_BASE_URL === 'undefined') {
    // API endpoints (routed through secure proxy)
    self.OPENAI_BASE_URL = 'https://my-webten-proxy-d34725bef4b5.herokuapp.com/api/openai';
}

if (typeof self.GROK_BASE_URL === 'undefined') {
    self.GROK_BASE_URL = 'https://my-webten-proxy-d34725bef4b5.herokuapp.com/api/grok';
}

if (typeof self.GROK_MODEL === 'undefined') {
    self.GROK_MODEL = 'grok-3-latest';
}

if (typeof self.GROK_API_KEY === 'undefined') {
    // API keys (these should be handled by the proxy server, but define them to prevent errors)
    self.GROK_API_KEY = 'proxy-handled';
}

if (typeof self.OPENAI_API_KEY === 'undefined') {
    self.OPENAI_API_KEY = 'proxy-handled';
}

// General Configuration
if (typeof self.CONFIG === 'undefined') {
    self.CONFIG = {
        MAX_PAGES: 20,
        EVENTS_PER_PAGE: 200, // For Kalshi
        KALSHI_PAGE_DELAY: 250, // ms between paginated Kalshi requests to avoid rate limiting
        KALSHI_MAX_CONCURRENCY: 4, // max simultaneous Kalshi event fetches to avoid rate limiting
        MARKETS_PER_PAGE: 200, // For Polymarket
        MAX_RELEVANT_MARKETS: 8,
        MAX_MARKETS_FOR_ANALYSIS: 4000,
        API_TIMEOUT: 30000,
        ANALYSIS_TIMEOUT: 180000,
        EMBEDDING_MODEL: 'text-embedding-ada-002',
        EMBEDDING_BATCH_SIZE: 20,
        EMBEDDING_CACHE_EXPIRY: 24 * 60 * 60 * 1000,
        BATCH_DELAY: 500,
        MAX_STORAGE_SIZE: 5 * 1024 * 1024,
        MAX_RETRY_ATTEMPTS: 3,
        RETRY_DELAY_BASE: 1000,
        MAX_MISPRICING_ANALYSES: 100,
        MISPRICING_SKIP_THRESHOLD: 30, // Skip mispricing analysis entirely when more than this many markets are relevant (too slow)
        MISPRICING_CACHE_EXPIRY: 60 * 60 * 1000
    };
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        PROXY_URL: self.PROXY_URL,
        OPENAI_BASE_URL: self.OPENAI_BASE_URL,
        GROK_BASE_URL: self.GROK_BASE_URL,
        GROK_MODEL: self.GROK_MODEL,
        GROK_API_KEY: self.GROK_API_KEY,
        OPENAI_API_KEY: self.OPENAI_API_KEY,
        CONFIG: self.CONFIG
    };
}
